// JavaScript Document
$('#submitPostButton').click(function() {    
	$('.ul_current').append('<li>' + "<div><strong>" + $('#input_listName').val() + ":</strong></div>" + "<div>" + $('#input_listContent').val() + "</div>" + '</li>' + '<hr />' );
resetform();
});

function resetform() {
document.getElementById("postForm").reset();
}